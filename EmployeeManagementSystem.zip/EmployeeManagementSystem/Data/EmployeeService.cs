using System.Data;
using System.Data.SqlClient;
using EmployeeManagementSystem.Models;

namespace EmployeeManagementSystem.Data
{
    public class EmployeeService
    {
        private readonly string _connectionString = "Server=DESKTOP-6027H4M\\SQLEXPRESS;Database=EmployeeDB;Trusted_Connection=True;";

        public List<Employee> GetAllEmployees()
        {
            var employees = new List<Employee>();
            using SqlConnection conn = new SqlConnection(_connectionString);
            using SqlCommand cmd = new SqlCommand("SELECT * FROM Employees", conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                employees.Add(new Employee
                {
                    EmployeeId = reader["EmployeeId"] != DBNull.Value ? Convert.ToInt32(reader["EmployeeId"]) : 0,
                    FullName = reader["FullName"] != DBNull.Value ? reader["FullName"]!.ToString()! : string.Empty,
                    Position = reader["Position"] != DBNull.Value ? reader["Position"]!.ToString()! : string.Empty,
                    Salary = reader["Salary"] != DBNull.Value ? Convert.ToDecimal(reader["Salary"]) : 0
                });
            }

            return employees;
        }

       
        public void AddEmployee(Employee emp)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            using SqlCommand cmd = new SqlCommand(
                "INSERT INTO Employees (FullName, Position, Salary) VALUES (@FullName, @Position, @Salary)", conn);

            cmd.Parameters.AddWithValue("@FullName", emp.FullName ?? string.Empty);
            cmd.Parameters.AddWithValue("@Position", emp.Position ?? string.Empty);
            cmd.Parameters.AddWithValue("@Salary", emp.Salary);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public void UpdateEmployee(Employee emp)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            using SqlCommand cmd = new SqlCommand(
                "UPDATE Employees SET FullName=@FullName, Position=@Position, Salary=@Salary WHERE EmployeeId=@EmployeeId", conn);

            cmd.Parameters.AddWithValue("@FullName", emp.FullName ?? string.Empty);
            cmd.Parameters.AddWithValue("@Position", emp.Position ?? string.Empty);
            cmd.Parameters.AddWithValue("@Salary", emp.Salary);
            cmd.Parameters.AddWithValue("@EmployeeId", emp.EmployeeId);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        
        public void DeleteEmployee(int id)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            using SqlCommand cmd = new SqlCommand(
                "DELETE FROM Employees WHERE EmployeeId=@EmployeeId", conn);

            cmd.Parameters.AddWithValue("@EmployeeId", id);

            conn.Open();
            cmd.ExecuteNonQuery();
        }
    }
}
